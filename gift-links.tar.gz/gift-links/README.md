# Gift Links — подарок в корзину по ссылке из письма

Shopify-приложение для WoodenCrew. В админке вы создаёте «гифт-кампании»: какой товар дарим,
какой промокод применяем, от какой суммы корзины. Для каждой кампании приложение даёт ссылку
вида `https://woodencrew.store/?gift=giftweek`, её ставите на кнопки в письме.

**Что видит клиент:** переходит по ссылке → код применяется сам → как только в корзине есть
товар на нужную сумму, подарок сам появляется в корзине за $0. Если товар убрать, подарок
тоже уходит. Кампания «помнится» в браузере 7 дней.

## Из чего состоит
| Часть | Где | Что делает |
|---|---|---|
| Админка | `app/routes/app._index.tsx`, `app/routes/app.campaigns.$id.tsx` | список кампаний, форма (выбор товара-подарка, промокода, минимальной суммы, дат, баннера), копирование ссылки |
| Хранение | `app/campaigns.server.ts` | все кампании лежат в одном app-metafield магазина (базы данных для кампаний нет) |
| Скрипт витрины | `extensions/gift-links-embed/` | app embed в теме: читает кампании и управляет подарком в корзине |

## Ограничения (честно)
- Код, введённый **на странице чекаута Shopify**, товар добавить не может, это разрешено только на Shopify Plus.
  Работают: ссылка `?gift=…` и поле промокода в корзине или cart drawer темы (если оно есть).
  Для заказов, где код ввели на чекауте, можно подстраховаться Shopify Flow (Order created → код = X → Add order line item, Add for free).
- Цена $0 даёт ваша скидка (Buy X Get Y, подарок 100% off). Приложение кладёт подарок и применяет код, но саму скидку не создаёт.
- Cart drawer: для тем семейства Dawn обновляется автоматически. В других темах подарок может появиться в drawer
  только после обновления страницы. Если тема другая, напишите, добавлю поддержку.

---

## Установка (один раз, ~30–40 минут)

### 0. Что нужно
- Node.js 22+ на компьютере и на сервере
- Shopify CLI: `npm i -g @shopify/cli`
- Аккаунт в Shopify Dev Dashboard / Partners (бесплатно), вход тем же email, что и в магазин

### 1. Создать приложение и привязать код
```bash
cd gift-links
npm install
shopify app config link        # «Create a new app» → имя Gift Links
```
CLI заполнит `client_id` в `shopify.app.toml`.

### 2. Попробовать локально (необязательно)
```bash
shopify app dev                # выберите магазин woodencrew; CLI сам поднимет туннель
```
Откройте ссылку из терминала, установите приложение и создайте тестовую кампанию.

### 3. Продакшн на вашем DigitalOcean-дроплете
1. DNS: A-запись `giftlinks.<ваш домен>` → IP дроплета.
2. На сервере:
   ```bash
   git clone <ваш репозиторий> /var/www/gift-links   # или залейте папку по scp
   cd /var/www/gift-links
   cp deploy/env.example .env   # впишите SHOPIFY_API_KEY / SECRET из Dev Dashboard и URL
   npm ci && npm run setup && npm run build
   npm i -g pm2 && pm2 start deploy/ecosystem.config.cjs && pm2 save && pm2 startup
   ```
3. nginx: скопируйте `deploy/nginx-gift-links.conf`, впишите домен, затем
   `ln -s /etc/nginx/sites-available/gift-links /etc/nginx/sites-enabled/ && nginx -t && systemctl reload nginx`
   и `certbot --nginx -d giftlinks.<ваш домен>`.
4. На компьютере в `shopify.app.toml` поменяйте `application_url` и `redirect_urls` на
   `https://giftlinks.<ваш домен>` (и `/auth/callback`), затем:
   ```bash
   shopify app deploy           # отправит конфиг и app embed в Shopify
   ```
5. Dev Dashboard → приложение → Distribution → **Custom distribution** → домен магазина → ссылка установки → Install.

### 4. Включить в теме
Admin → Online Store → Themes → Customize → **App embeds** → включить **Gift Links** → Save.
(В админке приложения есть страница «Setup guide» с кнопкой прямо туда.)

---

## Как запустить акцию
1. **Discounts → Buy X get Y (код)**, например `GIFTSTICK`:
   Customer buys: коллекция `All products – GWP`, Minimum purchase amount $10.
   Customer gets: Stain Remover Stick, 1 шт., Free. Max uses per order: 1. Combinations: включить product/order.
2. **Gift Links → New campaign**: имя, подарок (Stain Remover Stick), код `GIFTSTICK`,
   минимум $10 (та же сумма, что в скидке), даты, баннер → Save → **Copy link**.
3. Ставите ссылку на кнопки в письме.
4. Тест в инкогнито: ссылка → добавить товар → подарок в корзине → чекаут: подарок $0.

## Настройки кампании
| Поле | Смысл |
|---|---|
| Link key | часть ссылки `?gift=…` |
| Landing page path | куда ведёт ссылка (`/`, `/collections/all`, страница товара) |
| Minimum cart subtotal | сумма корзины без подарка, с которой добавляется подарок |
| Add even while cart is empty | положить подарок сразу после клика, ещё до покупок |
| Remove if cart stops qualifying | убрать подарок, если корзина перестала подходить |
| Also start when code typed in cart | запускать кампанию, когда код ввели в корзине |
| Starts / Ends | даты действия (Ends включительно) |
| Storefront banner | плашка внизу сайта после перехода по ссылке |

Отладка: в настройках app embed включите «Debug log», в консоли браузера будут сообщения `[Gift Links]`.
