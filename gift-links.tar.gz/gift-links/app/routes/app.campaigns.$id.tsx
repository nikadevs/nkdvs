import { useEffect, useState } from "react";
import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import {
  redirect,
  useActionData,
  useLoaderData,
  useNavigate,
  useNavigation,
  useSubmit,
} from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { type Campaign, campaignLink } from "../campaigns.shared";
import {
  campaignFromForm,
  loadConfig,
  loadDiscountCodes,
  loadShopDomain,
  saveConfig,
} from "../campaigns.server";

const blank = (): Campaign => ({
  id: "new",
  name: "",
  active: true,
  linkKey: "",
  giftVariantId: "",
  giftTitle: "",
  giftImage: "",
  discountCode: "",
  triggerOnCode: true,
  minSubtotal: 10,
  addWhenCartEmpty: false,
  removeWhenIneligible: true,
  bannerText:
    "🎁 Your free gift is waiting — it's added to your cart automatically",
  landingPath: "/",
  startsAt: "",
  endsAt: "",
  updatedAt: "",
});

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const [{ config }, discounts, domain] = await Promise.all([
    loadConfig(admin),
    loadDiscountCodes(admin),
    loadShopDomain(admin),
  ]);
  const campaign =
    params.id === "new"
      ? blank()
      : config.campaigns.find((c) => c.id === params.id);
  if (!campaign) throw redirect("/app");
  return { campaign, discounts, domain };
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const { installationId, config } = await loadConfig(admin);
  const id =
    params.id === "new"
      ? `c_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`
      : String(params.id);

  const { campaign, errors } = campaignFromForm(form, config.campaigns, id);
  if (!campaign) return { errors };

  const idx = config.campaigns.findIndex((c) => c.id === id);
  if (idx >= 0) config.campaigns[idx] = campaign;
  else config.campaigns.push(campaign);

  try {
    await saveConfig(admin, installationId, config);
  } catch (e) {
    return { errors: { form: (e as Error).message } };
  }
  return redirect(`/app/campaigns/${id}?saved=1`);
};

type FieldEvent = Event & {
  currentTarget: { value?: string; checked?: boolean };
};
const val = (e: Event) => String((e as FieldEvent).currentTarget?.value ?? "");
const chk = (e: Event) => Boolean((e as FieldEvent).currentTarget?.checked);

export default function CampaignRoute() {
  const data = useLoaderData<typeof loader>();
  // re-mount the form whenever a different/saved campaign is loaded
  return (
    <CampaignForm
      key={`${data.campaign.id}:${data.campaign.updatedAt}`}
      {...data}
    />
  );
}

function CampaignForm({
  campaign,
  discounts,
  domain,
}: Awaited<ReturnType<typeof loader>>) {
  const actionData = useActionData<typeof action>();
  const errors: Record<string, string> = actionData?.errors ?? {};
  const [c, setC] = useState<Campaign>(campaign);
  const submit = useSubmit();
  const nav = useNavigation();
  const navigate = useNavigate();
  const shopify = useAppBridge();
  const isNew = campaign.id === "new";
  const saving = nav.state === "submitting";

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get("saved"))
      shopify.toast.show("Campaign saved");
  }, [campaign.updatedAt, shopify]);

  const set = <K extends keyof Campaign>(k: K, v: Campaign[K]) =>
    setC((prev) => ({ ...prev, [k]: v }));

  const pickGift = async () => {
    const selected = (await shopify.resourcePicker({
      type: "product",
      multiple: false,
      filter: { variants: true, draft: false, archived: false },
    })) as
      | Array<{
          title: string;
          images?: { originalSrc?: string; url?: string }[];
          variants: {
            id: string;
            title?: string;
            image?: { originalSrc?: string; url?: string };
          }[];
        }>
      | undefined;
    const product = selected?.[0];
    const variant = product?.variants?.[0];
    if (!product || !variant) return;
    const img =
      variant.image?.originalSrc ??
      variant.image?.url ??
      product.images?.[0]?.originalSrc ??
      product.images?.[0]?.url ??
      "";
    const vTitle =
      variant.title && variant.title !== "Default Title"
        ? ` — ${variant.title}`
        : "";
    setC((prev) => ({
      ...prev,
      giftVariantId: variant.id.replace(/\D/g, ""),
      giftTitle: product.title + vTitle,
      giftImage: img,
    }));
  };

  const save = () => {
    const fd = new FormData();
    for (const [k, v] of Object.entries(c)) {
      if (typeof v === "boolean") {
        if (v) fd.append(k, "on");
      } else fd.append(k, String(v));
    }
    submit(fd, { method: "POST" });
  };

  const previewKey =
    (c.linkKey || c.name)
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9-]+/g, "-")
      .replace(/^-+|-+$/g, "") || "your-key";
  const link = campaignLink(domain || "https://your-store.com", {
    ...c,
    landingPath: c.landingPath || "/",
    linkKey: previewKey,
  });

  const codeKnown = discounts.some(
    (d) => d.code.toUpperCase() === c.discountCode.toUpperCase(),
  );

  return (
    <s-page heading={isNew ? "New gift campaign" : c.name || "Gift campaign"}>
      <s-link slot="breadcrumb-actions" href="/app">
        Gift campaigns
      </s-link>
      <s-button
        slot="primary-action"
        variant="primary"
        onClick={save}
        {...(saving ? { loading: true } : {})}
      >
        Save
      </s-button>
      <s-button slot="secondary-actions" onClick={() => navigate("/app")}>
        Cancel
      </s-button>

      {errors.form ? (
        <s-banner tone="critical" heading="Could not save">
          {errors.form}
        </s-banner>
      ) : null}

      <s-section heading="Campaign">
        <s-stack direction="block" gap="base">
          <s-text-field
            label="Name"
            placeholder="Gift Week — Stain Remover"
            value={c.name}
            error={errors.name}
            onInput={(e: Event) => set("name", val(e))}
          />
          <s-text-field
            label="Link key"
            details="Goes into the link as ?gift=… Letters, numbers and dashes."
            placeholder={previewKey}
            value={c.linkKey}
            error={errors.linkKey}
            onInput={(e: Event) => set("linkKey", val(e))}
          />
          <s-text-field
            label="Landing page path"
            details='Where the email link opens, e.g. "/" or "/collections/all"'
            value={c.landingPath}
            onInput={(e: Event) => set("landingPath", val(e))}
          />
          <s-switch
            label="Campaign is active"
            checked={c.active}
            onChange={(e: Event) => set("active", chk(e))}
          />
        </s-stack>
      </s-section>

      <s-section heading="Gift">
        <s-stack direction="block" gap="base">
          {c.giftVariantId ? (
            <s-stack direction="inline" gap="base" alignItems="center">
              {c.giftImage ? (
                <s-thumbnail src={c.giftImage} alt="" size="small" />
              ) : null}
              <s-stack direction="block" gap="none">
                <s-text type="strong">{c.giftTitle}</s-text>
                <s-text color="subdued">Variant ID {c.giftVariantId}</s-text>
              </s-stack>
              <s-button onClick={pickGift}>Change</s-button>
            </s-stack>
          ) : (
            <s-button onClick={pickGift}>Select gift product</s-button>
          )}
          {errors.gift ? <s-text tone="critical">{errors.gift}</s-text> : null}
          <s-number-field
            label="Minimum cart subtotal (without the gift)"
            details="The gift is added once the rest of the cart reaches this amount. Match it to your discount's minimum."
            min={0}
            step={1}
            value={String(c.minSubtotal)}
            error={errors.minSubtotal}
            onInput={(e: Event) => set("minSubtotal", Number(val(e) || 0))}
          />
          <s-checkbox
            label="Add the gift even while the cart is empty"
            details="Off = the gift appears after the shopper adds their first product (recommended for Buy X Get Y codes)."
            checked={c.addWhenCartEmpty}
            onChange={(e: Event) => set("addWhenCartEmpty", chk(e))}
          />
          <s-checkbox
            label="Remove the gift if the cart stops qualifying"
            checked={c.removeWhenIneligible}
            onChange={(e: Event) => set("removeWhenIneligible", chk(e))}
          />
        </s-stack>
      </s-section>

      <s-section heading="Discount">
        <s-stack direction="block" gap="base">
          <s-select
            label="Discount code to apply"
            details="Use a Buy X Get Y code where the gift is the 'Customer gets' item at 100% off, with combinations enabled."
            value={codeKnown ? c.discountCode.toUpperCase() : ""}
            onChange={(e: Event) => set("discountCode", val(e))}
          >
            <s-option value="">— No code (gift only) —</s-option>
            {discounts.map((d) => (
              <s-option key={d.code} value={d.code.toUpperCase()}>
                {`${d.code}${d.title !== d.code ? ` · ${d.title}` : ""}${d.status && d.status !== "ACTIVE" ? ` (${d.status.toLowerCase()})` : ""}`}
              </s-option>
            ))}
          </s-select>
          <s-text-field
            label="…or type code(s)"
            details="Several codes? Separate with commas, e.g. GIFTSTICK,GIFTSTICK10 — all are applied together (enable combinations)."
            value={c.discountCode}
            onInput={(e: Event) => set("discountCode", val(e).toUpperCase())}
          />
          <s-checkbox
            label="Also start the campaign when a shopper types this code in the cart"
            details="Works with cart pages/drawers that have a discount field. Codes typed on the Shopify checkout page can't add products (Shopify Plus only)."
            checked={c.triggerOnCode}
            onChange={(e: Event) => set("triggerOnCode", chk(e))}
          />
        </s-stack>
      </s-section>

      <s-section heading="Schedule & banner">
        <s-stack direction="block" gap="base">
          <s-grid gridTemplateColumns="1fr 1fr" gap="base">
            <s-date-field
              label="Starts (optional)"
              value={c.startsAt}
              error={errors.startsAt}
              onChange={(e: Event) => set("startsAt", val(e))}
            />
            <s-date-field
              label="Ends (optional, inclusive)"
              value={c.endsAt}
              error={errors.endsAt}
              onChange={(e: Event) => set("endsAt", val(e))}
            />
          </s-grid>
          <s-text-field
            label="Storefront banner (optional)"
            details="Shown at the top of the store after the link is clicked. Leave empty for no banner."
            value={c.bannerText}
            onInput={(e: Event) => set("bannerText", val(e))}
          />
        </s-stack>
      </s-section>

      <s-section slot="aside" heading="Email link">
        <s-stack direction="block" gap="base">
          <s-box padding="base" background="subdued" borderRadius="base">
            <s-text>{link}</s-text>
          </s-box>
          <s-button
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(link);
                shopify.toast.show("Link copied");
              } catch {
                shopify.toast.show("Copy failed — select the link manually");
              }
            }}
          >
            Copy link
          </s-button>
          <s-paragraph>
            Save first — the link works once the campaign is saved and active.
          </s-paragraph>
        </s-stack>
      </s-section>

      <s-section slot="aside" heading="Checklist">
        <s-unordered-list>
          <s-list-item>
            Gift product is active and published to Online Store
          </s-list-item>
          <s-list-item>
            Discount: gift is the “Customer gets” item, 100% off
          </s-list-item>
          <s-list-item>
            Discount combinations enabled if you run other sales
          </s-list-item>
          <s-list-item>
            App embed “Gift Links” is on in Theme editor
          </s-list-item>
        </s-unordered-list>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
