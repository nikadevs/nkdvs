import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useState } from "react";
import { useFetcher, useLoaderData, useNavigate } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import {
  campaignLink,
  campaignStatus,
  loadConfig,
  loadShopDomain,
  saveConfig,
} from "../campaigns.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const [{ config }, domain] = await Promise.all([
    loadConfig(admin),
    loadShopDomain(admin),
  ]);
  return {
    campaigns: config.campaigns.map((c) => ({
      ...c,
      link: campaignLink(domain, c),
      status: campaignStatus(c),
    })),
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  const id = String(form.get("id"));
  const { installationId, config } = await loadConfig(admin);

  if (intent === "delete") {
    config.campaigns = config.campaigns.filter((c) => c.id !== id);
  } else if (intent === "toggle") {
    config.campaigns = config.campaigns.map((c) =>
      c.id === id
        ? { ...c, active: !c.active, updatedAt: new Date().toISOString() }
        : c,
    );
  }
  await saveConfig(admin, installationId, config);
  return { ok: true, intent };
};

const tone = (s: string) =>
  s === "Live" ? "success" : s === "Scheduled" ? "info" : "neutral";

export default function Campaigns() {
  const { campaigns } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const navigate = useNavigate();
  const shopify = useAppBridge();
  const [confirmId, setConfirmId] = useState("");

  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      shopify.toast.show("Link copied");
    } catch {
      shopify.toast.show("Copy failed — select the link manually");
    }
  };

  const submit = (intent: string, id: string) =>
    fetcher.submit({ intent, id }, { method: "POST" });

  return (
    <s-page heading="Gift campaigns">
      <s-button
        slot="primary-action"
        variant="primary"
        onClick={() => navigate("/app/campaigns/new")}
      >
        New campaign
      </s-button>

      {campaigns.length === 0 ? (
        <s-section>
          <s-stack direction="block" gap="base" alignItems="center">
            <s-heading>No gift campaigns yet</s-heading>
            <s-paragraph>
              Create a campaign, pick the gift and the discount code, and get a
              link for your email. Shoppers who click it get the gift added to
              their cart automatically.
            </s-paragraph>
            <s-button
              variant="primary"
              onClick={() => navigate("/app/campaigns/new")}
            >
              Create first campaign
            </s-button>
          </s-stack>
        </s-section>
      ) : (
        <s-section padding="none">
          <s-table>
            <s-table-header-row>
              <s-table-header>Campaign</s-table-header>
              <s-table-header>Gift</s-table-header>
              <s-table-header>Code</s-table-header>
              <s-table-header>Status</s-table-header>
              <s-table-header>Email link</s-table-header>
              <s-table-header>Actions</s-table-header>
            </s-table-header-row>
            <s-table-body>
              {campaigns.map((c) => (
                <s-table-row key={c.id}>
                  <s-table-cell>
                    <s-link href={`/app/campaigns/${c.id}`}>{c.name}</s-link>
                  </s-table-cell>
                  <s-table-cell>
                    <s-stack
                      direction="inline"
                      gap="small-200"
                      alignItems="center"
                    >
                      {c.giftImage ? (
                        <s-thumbnail
                          src={c.giftImage}
                          alt=""
                          size="small-200"
                        />
                      ) : null}
                      <s-text>
                        {c.giftTitle || `Variant ${c.giftVariantId}`}
                      </s-text>
                    </s-stack>
                  </s-table-cell>
                  <s-table-cell>{c.discountCode || "—"}</s-table-cell>
                  <s-table-cell>
                    <s-badge tone={tone(c.status)}>{c.status}</s-badge>
                  </s-table-cell>
                  <s-table-cell>
                    <s-button variant="tertiary" onClick={() => copy(c.link)}>
                      Copy link
                    </s-button>
                  </s-table-cell>
                  <s-table-cell>
                    <s-stack direction="inline" gap="small-200">
                      <s-button onClick={() => submit("toggle", c.id)}>
                        {c.active ? "Pause" : "Activate"}
                      </s-button>
                      <s-button
                        tone="critical"
                        variant="tertiary"
                        onClick={() => {
                          if (confirmId === c.id) {
                            setConfirmId("");
                            submit("delete", c.id);
                          } else setConfirmId(c.id);
                        }}
                      >
                        {confirmId === c.id
                          ? "Click again to delete"
                          : "Delete"}
                      </s-button>
                    </s-stack>
                  </s-table-cell>
                </s-table-row>
              ))}
            </s-table-body>
          </s-table>
        </s-section>
      )}

      <s-section slot="aside" heading="How it works">
        <s-ordered-list>
          <s-list-item>
            Create a campaign: gift product + discount code.
          </s-list-item>
          <s-list-item>
            Put the campaign link behind the buttons in your email.
          </s-list-item>
          <s-list-item>
            The shopper clicks → the code is applied and the gift lands in the
            cart as soon as the cart qualifies.
          </s-list-item>
        </s-ordered-list>
        <s-paragraph>
          The app embed must be on in your theme.{" "}
          <s-link href="/app/setup">Setup guide</s-link>
        </s-paragraph>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
