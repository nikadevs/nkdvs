/*!
 * Gift Links — storefront script (theme app embed)
 *
 * 1. Shopper opens a link with ?gift=<linkKey>  → campaign is remembered for 7 days.
 *    (Optionally also when the campaign's discount code is typed in the cart.)
 * 2. Whenever the cart changes, the script checks the cart:
 *      qualifies  → adds the gift variant (qty 1) and applies the campaign code
 *      no longer  → removes the gift it added (if the campaign says so)
 * 3. The discount (e.g. Buy X Get Y, gift 100% off) makes the gift $0 at checkout.
 */
(function () {
  "use strict";

  var script = document.getElementById("gift-links-script");
  var cfgEl = document.getElementById("gift-links-config");
  if (!script || !cfgEl || window.__giftLinksLoaded) return;
  window.__giftLinksLoaded = true;

  var DEBUG = script.dataset.debug === "true";
  var ROOT = (script.dataset.root || "/").replace(/\/?$/, "/");
  var STORE_KEY = "giftLinks.active.v1";
  var BANNER_KEY = "giftLinks.bannerClosed.v1";
  var TTL_MS = 7 * 24 * 60 * 60 * 1000;
  var LINE_PROP = "_gift_link"; // hidden line-item property marking OUR gift line

  function log() {
    if (DEBUG && window.console)
      console.log.apply(
        console,
        ["[Gift Links]"].concat([].slice.call(arguments)),
      );
  }

  // ---------- config ----------
  var config;
  try {
    config = JSON.parse(cfgEl.textContent || "{}");
  } catch (e) {
    return;
  }
  var campaigns = (config && config.campaigns) || [];
  if (!campaigns.length) return;

  function today() {
    var d = new Date();
    var m = d.getMonth() + 1;
    var day = d.getDate();
    return (
      d.getFullYear() +
      "-" +
      (m < 10 ? "0" : "") +
      m +
      "-" +
      (day < 10 ? "0" : "") +
      day
    );
  }
  function isLive(c) {
    if (!c || !c.active || !c.giftVariantId) return false;
    var t = today();
    if (c.startsAt && t < c.startsAt) return false;
    if (c.endsAt && t > c.endsAt) return false;
    return true;
  }
  function byId(id) {
    for (var i = 0; i < campaigns.length; i++)
      if (campaigns[i].id === id) return campaigns[i];
    return null;
  }
  function byKey(key) {
    key = String(key || "").toLowerCase();
    for (var i = 0; i < campaigns.length; i++)
      if (campaigns[i].linkKey === key) return campaigns[i];
    return null;
  }

  // ---------- storage (never throws) ----------
  function readStore(k) {
    try {
      return JSON.parse(window.localStorage.getItem(k) || "null");
    } catch (e) {
      return null;
    }
  }
  function writeStore(k, v) {
    try {
      if (v === null) window.localStorage.removeItem(k);
      else window.localStorage.setItem(k, JSON.stringify(v));
    } catch (e) {
      // ignore
    }
  }

  var state = readStore(STORE_KEY); // { id, ts, codeApplied }
  function activate(c, reason) {
    state = { id: c.id, ts: Date.now(), codeApplied: false };
    writeStore(STORE_KEY, state);
    log("campaign activated:", c.name, "via", reason);
  }
  function activeCampaign() {
    if (!state || !state.id) return null;
    if (Date.now() - (state.ts || 0) > TTL_MS) {
      writeStore(STORE_KEY, null);
      state = null;
      return null;
    }
    var c = byId(state.id);
    return isLive(c) ? c : null;
  }

  // ---------- link trigger ----------
  try {
    var url = new URL(window.location.href);
    var key = url.searchParams.get("gift");
    if (key) {
      var linked = byKey(key);
      if (isLive(linked)) activate(linked, "link");
      else log("link key not found or campaign not live:", key);
      url.searchParams.delete("gift");
      window.history.replaceState(
        window.history.state,
        "",
        url.pathname + url.search + url.hash,
      );
    }
  } catch (e) {
    // ignore
  }

  // ---------- cart helpers (use the original fetch so we don't trigger ourselves) ----------
  var rawFetch = window.fetch.bind(window);
  function api(path, body) {
    return rawFetch(ROOT + path, {
      method: body ? "POST" : "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      credentials: "same-origin",
      body: body ? JSON.stringify(body) : undefined,
    }).then(function (r) {
      if (!r.ok) throw new Error(path + " " + r.status);
      return r.json();
    });
  }
  function rate() {
    var r =
      window.Shopify &&
      window.Shopify.currency &&
      Number(window.Shopify.currency.rate);
    return r && r > 0 ? r : 1;
  }
  function campaignCodes(c) {
    return String((c && c.discountCode) || "")
      .toUpperCase()
      .split(/[\s,]+/)
      .filter(Boolean);
  }
  function cartCodes(cart) {
    var list = cart && cart.discount_codes;
    if (!Array.isArray(list)) return null; // field not available on this store/theme
    return list.map(function (d) {
      return String((d && d.code) || "").toUpperCase();
    });
  }

  // ---------- core sync ----------
  var busy = false;
  var again = false;
  var runs = [];

  function sync() {
    if (busy) {
      again = true;
      return Promise.resolve();
    }
    // safety valve: max 6 runs per 10 seconds
    var now = Date.now();
    runs = runs.filter(function (t) {
      return now - t < 10000;
    });
    if (runs.length >= 6) return Promise.resolve();
    runs.push(now);

    busy = true;
    var changed = false;

    return api("cart.js")
      .then(function (cart) {
        var c = activeCampaign();
        var codes = cartCodes(cart);

        // code typed in the cart → start that campaign
        if (!c && codes) {
          for (var i = 0; i < campaigns.length; i++) {
            var cc = campaigns[i];
            if (
              cc.triggerOnCode &&
              isLive(cc) &&
              campaignCodes(cc).some(function (x) {
                return codes.indexOf(x) >= 0;
              })
            ) {
              activate(cc, "code");
              state.codeApplied = true;
              writeStore(STORE_KEY, state);
              c = cc;
              break;
            }
          }
        }

        var ours = cart.items.filter(function (it) {
          return it.properties && it.properties[LINE_PROP];
        });

        // $0 gift products can only be in the cart via a campaign: remove copies added by hand / direct links
        var giftIds = campaigns.map(function (x) {
          return String(x.giftVariantId);
        });
        var rogue = cart.items.filter(function (it) {
          return (
            !(it.properties && it.properties[LINE_PROP]) &&
            giftIds.indexOf(String(it.variant_id)) >= 0 &&
            Number(it.original_price) === 0
          );
        });
        if (rogue.length) {
          var updR = {};
          rogue.forEach(function (it) {
            updR[it.key] = 0;
          });
          changed = true;
          log("removing gift added outside a campaign");
          return api("cart/update.js", { updates: updR }).then(function () {
            again = true;
          });
        }

        // no live campaign → clean up any gift line we added earlier
        if (!c) {
          if (!ours.length) return null;
          var updates0 = {};
          ours.forEach(function (it) {
            updates0[it.key] = 0;
          });
          changed = true;
          log("campaign over — removing gift lines");
          return api("cart/update.js", { updates: updates0 });
        }

        var giftId = String(c.giftVariantId);
        var giftLines = ours.filter(function (it) {
          return String(it.variant_id) === giftId;
        });
        var strayLines = ours.filter(function (it) {
          return String(it.variant_id) !== giftId; // gift from a previous campaign
        });
        var paid = cart.items.filter(function (it) {
          return (
            !(it.properties && it.properties[LINE_PROP]) &&
            String(it.variant_id) !== giftId &&
            it.final_line_price > 0
          );
        });
        var subtotal =
          paid.reduce(function (s, it) {
            return s + it.final_line_price;
          }, 0) /
          100 /
          rate();
        var eligible =
          c.addWhenCartEmpty ||
          (paid.length > 0 && subtotal >= Number(c.minSubtotal || 0));
        log("cart subtotal (w/o gift):", subtotal, "eligible:", eligible);

        var chain = Promise.resolve(null);
        var updates = {};
        strayLines.forEach(function (it) {
          updates[it.key] = 0;
        });

        var addedGift = false;
        if (eligible) {
          if (!giftLines.length) {
            changed = true;
            addedGift = true;
            var props = {};
            props[LINE_PROP] = c.name || "Gift";
            chain = chain.then(function () {
              log("adding gift", giftId);
              return api("cart/add.js", {
                items: [{ id: Number(giftId), quantity: 1, properties: props }],
              });
            });
          } else {
            giftLines.forEach(function (it, idx) {
              var want = idx === 0 ? 1 : 0;
              if (it.quantity !== want) updates[it.key] = want;
            });
          }
        } else if (giftLines.length && c.removeWhenIneligible) {
          giftLines.forEach(function (it) {
            updates[it.key] = 0;
          });
          log("cart no longer qualifies — removing gift");
        }

        if (Object.keys(updates).length) {
          changed = true;
          chain = chain.then(function () {
            return api("cart/update.js", { updates: updates });
          });
        }

        // apply the discount code once the gift is in (Buy X Get Y needs it in the cart)
        var want = campaignCodes(c);
        if (want.length) {
          // when the theme's cart.js doesn't expose discount_codes we re-apply after each gift add
          var missing = codes
            ? want.some(function (x) {
                return codes.indexOf(x) < 0;
              })
            : !state.codeApplied || addedGift;
          // safety: never retry a refused code more than twice per 10 minutes (prevents reload loops)
          var now2 = Date.now();
          if (!state.applyTs || now2 - state.applyTs > 600000) {
            state.applyTs = now2;
            state.applyTries = 0;
          }
          if (eligible && missing && (state.applyTries || 0) < 2) {
            chain = chain.then(function () {
              var merged = (codes || []).filter(function (x) {
                return x && want.indexOf(x) < 0;
              });
              merged = merged.concat(want);
              log("applying discount", merged.join(","));
              state.codeApplied = true;
              state.applyTries = (state.applyTries || 0) + 1;
              writeStore(STORE_KEY, state);
              changed = true;
              return api("cart/update.js", { discount: merged.join(",") });
            });
          }
        }
        return chain;
      })
      .catch(function (e) {
        log("error", e && e.message);
      })
      .then(function () {
        busy = false;
        if (changed) refreshUI();
        renderBanner();
        if (again) {
          again = false;
          return sync();
        }
      });
  }

  // ---------- refresh the theme's cart UI ----------
  function refreshUI() {
    try {
      document.dispatchEvent(
        new CustomEvent("gift-links:cart-updated", { bubbles: true }),
      );
    } catch (e) {
      // ignore
    }
    var path = window.location.pathname.replace(/\/$/, "");
    if (/\/cart$/.test(path)) {
      window.location.reload();
      return;
    }
    // Dawn-family themes: re-render cart icon + drawer sections if present
    var ids = [];
    if (document.getElementById("cart-icon-bubble"))
      ids.push("cart-icon-bubble");
    if (document.getElementById("CartDrawer")) ids.push("cart-drawer");
    if (!ids.length) return;
    rawFetch(ROOT + "?sections=" + ids.join(","), {
      credentials: "same-origin",
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (sections) {
        var parse = function (html, sel) {
          var doc = new DOMParser().parseFromString(html, "text/html");
          return doc.querySelector(sel);
        };
        if (sections["cart-icon-bubble"]) {
          var bubble = document.getElementById("cart-icon-bubble");
          var nb =
            parse(sections["cart-icon-bubble"], ".shopify-section") ||
            parse(sections["cart-icon-bubble"], "body");
          if (bubble && nb) bubble.innerHTML = nb.innerHTML;
        }
        if (sections["cart-drawer"]) {
          var drawer = document.getElementById("CartDrawer");
          var nd = parse(sections["cart-drawer"], "#CartDrawer");
          if (drawer && nd) drawer.innerHTML = nd.innerHTML;
          var wrap = document.querySelector("cart-drawer.is-empty");
          if (wrap && nd && !nd.querySelector(".drawer__inner-empty"))
            wrap.classList.remove("is-empty");
        }
      })
      .catch(function () {});
  }

  // ---------- banner ----------
  function renderBanner() {
    var c = activeCampaign();
    var existing = document.getElementById("gift-links-banner");
    var closed = readStore(BANNER_KEY);
    if (!c || !c.bannerText || (closed && closed === c.id)) {
      if (existing) existing.remove();
      return;
    }
    if (existing) return;
    var bar = document.createElement("div");
    bar.id = "gift-links-banner";
    bar.setAttribute("role", "status");
    bar.style.cssText =
      "position:fixed;left:0;right:0;bottom:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;gap:12px;" +
      "padding:12px 44px 12px 16px;font:600 14px/1.4 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;text-align:center;" +
      "box-shadow:0 -2px 12px rgba(0,0,0,.12);background:" +
      (script.dataset.bannerBg || "#155F56") +
      ";color:" +
      (script.dataset.bannerColor || "#fff");
    var text = document.createElement("span");
    text.textContent = c.bannerText;
    var close = document.createElement("button");
    close.type = "button";
    close.setAttribute("aria-label", "Close");
    close.textContent = "×";
    close.style.cssText =
      "position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:0;color:inherit;font-size:22px;line-height:1;cursor:pointer;padding:4px 8px;";
    close.onclick = function () {
      writeStore(BANNER_KEY, c.id);
      bar.remove();
    };
    bar.appendChild(text);
    bar.appendChild(close);
    document.body.appendChild(bar);
  }

  // ---------- watch the theme's own cart requests ----------
  var CART_RE = /\/cart\/(add|change|update|clear)(\.js)?(\?|$)/;
  var timer = null;
  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(sync, 350);
  }
  window.fetch = function (input, init) {
    var p = rawFetch(input, init);
    try {
      var u = typeof input === "string" ? input : (input && input.url) || "";
      if (CART_RE.test(u)) p.then(schedule, function () {});
    } catch (e) {
      // ignore
    }
    return p;
  };
  var xhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, u) {
    try {
      if (CART_RE.test(String(u))) this.addEventListener("load", schedule);
    } catch (e) {
      // ignore
    }
    return xhrOpen.apply(this, arguments);
  };

  // public hook for themes/devs: window.GiftLinks.sync()
  window.GiftLinks = { sync: sync };

  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", sync);
  else sync();
})();
